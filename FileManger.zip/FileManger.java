/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ControlUnit;

import Users.Newcustomer;
import java.util.*;
import java.lang.*;
import java.io.*;
import Users.Oldcustomer;

public class FileManger implements Serializable {
    public Boolean write(String FilePath,Object data)
    { 
   
        try
        {
            System.out.print("\nwritting in ! " + FilePath);
            ObjectOutputStream Writter=new ObjectOutputStream(new FileOutputStream(FilePath));
            Writter.writeObject(data);
            System.out.println("Done");
            Writter.close();
            return true;
            
        }catch(Exception e)
        {  
            System.out.println("Can't write \n"+e);   
        }
        return false;
    }
    public Object read(String FilePath)
    {
        Object Result=null;
        try
        {  
           ObjectInputStream Reader=new ObjectInputStream(new FileInputStream(FilePath));
           Result=Reader.readObject();
        }catch(IOException | ClassNotFoundException e)
        {
            System.out.println("Can't Read"+e);
        }
        return Result;
    }
}
