/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ControlUnit;

import Users.Newcustomer;
import java.util.*;
import java.lang.*;
import java.io.*;
import Users.Oldcustomer;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FileManger implements Serializable {
    
    public Boolean write(String FilePath,Object data)
    { 
   
        try
        {
            System.out.print("\nwritting in ! " + FilePath+"\n");
            ObjectOutputStream Writter=new ObjectOutputStream(new FileOutputStream(FilePath));
            Writter.writeObject(data);
            System.out.println("Done");
            Writter.close();
            return true;
            
        }catch(Exception e)
        {  
            System.out.println("Can't write "+e);   
        }
        return false;
    }
    public Object read(String FilePath)
    {
        Object Result=null;
        try
        {  
            System.out.println("Reading ! From " + FilePath);
           ObjectInputStream Reader=  new ObjectInputStream(new FileInputStream(FilePath));
           Result=Reader.readObject();
        }
        catch(IOException E)
        {
            System.out.println("Can't Read "+E);
        }
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(FileManger.class.getName()).log(Level.SEVERE, null, ex);
        }
        return Result;
    }
    public Boolean Creat(String FileName)
    {
        try
        {
            File file = new File(FileName);
            if (file.createNewFile())
            System.out.println("File is created!");
            return true;
        }
        catch(IOException e)
        {    
          System.out.println(e+"File already exists.");
        }
                
        return false;
                
    }
     public boolean writetext(double Query, String FilePath, boolean appendType) {

        PrintWriter writter = null;
        try {
            System.out.print("\nwritting in ! " + FilePath);

            writter = new PrintWriter(new FileWriter(new File(FilePath), appendType));
            writter.println(Query);

            System.out.println(" ... Done ! ");
            return true;
        } catch (IOException e) {
            System.out.println(e);
        } finally {
            writter.close();
        }
        return false;
    }
}
