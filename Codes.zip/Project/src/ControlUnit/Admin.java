/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ControlUnit;
import ControlUnit.FileManger;
import Users.Newcustomer;
import Users.Newcustomer;
import Users.Oldcustomer;
import Users.Oldcustomer;
import ControlUnit.Operator;
import Users.Bill;
import Users.MyExceptions;
import Users.Newcustomer;
import Users.Oldcustomer;
import static Users.Oldcustomer.OldCustomer;
import Users.Person;
import Users.Region;
import java.io.Serializable;
import java.lang.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Admin extends Person implements Serializable{
    
    FileManger FManager=new FileManger();
    public static ArrayList<Integer> newmcode=new ArrayList<Integer>();
    
    public Admin()
    {
        super();
    }
    public Admin(String FName,String LName,String Email,String Password,String bday,int Age,int SSN)
    {
        super(FName, LName, Email, bday, Age, SSN);
    }
    public double TotalCollected()
    {
        Oldcustomer x=new Oldcustomer();
        return x.TotalCollected();
    }
    public ArrayList<Bill> veiwAllBills(int id)
    {
        Oldcustomer x=new Oldcustomer();
        return x.AllbillsofRegion(id);
    }
    public boolean addNewCustomer(String Fname,String Lname,String Email,String password,String bday,int age,int SSN,Region R)//fill information
     {
         Newcustomer x=new Newcustomer(Fname, Lname, Email, bday, age, SSN, R);
         if(x.addNewCustomer())
         {
             JOptionPane.showMessageDialog(null,x.toString() + " Added Successfully ... !");
             return true;
         }
         else
         JOptionPane.showMessageDialog(null,x.toString() + " Can't be Added ... !");
         return false;
         
     }
    public boolean addOldCustomer(String Fname,String Lname,String email,String password,String bday,int age,int SSN,Region R,int ID,String type,int phase)//New customer // Old Customer //Admins 
    {
        Oldcustomer x=new Oldcustomer(Fname, Lname, email, bday, age, SSN, R,ID, type, phase);
        if(x.addOldCustomer())
        {
            System.out.println(x.toString() + "Added Successfully ... !");
            return true;
        }
        else
        {
            System.out.println(x.toString() + "Added Successfully ... !");
            return false;
        }
        
    }
    public boolean deleteOldCustomer(long mcode)//New customer // Old Customer //Admins 
    {
        Oldcustomer x=new Oldcustomer();
        return x.deleteCustomer(mcode);
        
    }
    public boolean deleteNewCustomer(int SSN)//New customer // Old Customer //Admins 
    {
        Newcustomer x=new Newcustomer();
        return x.deleteCustomer(SSN);
        
    }
    public boolean updateNewCustomertoOld(int Mid,String Mtype,int Mphase,int SSN)
    {
        Newcustomer x=new Newcustomer();
        x=x.SearchCustomer(SSN);
        if(x!=null)
        {
           
           Oldcustomer y=new Oldcustomer(x.getFname(),x.getLname(),x.getEmail(),x.getbday(),x.getage(),x.getSSN(),x.getRegion(),Mid,Mtype,Mphase);
           y.addOldCustomer();
           x.deleteCustomer(x.getSSN());
           return true;
        }
        else
        {
            return false;
        }
    }
    public ArrayList<Oldcustomer> displayAllOldCustomer()
    {
        Oldcustomer x=new Oldcustomer();
        return x.displayAllOldCustomer();
    }
    public ArrayList<Newcustomer> displayAllNewCustomer()
    {
        Newcustomer x=new Newcustomer();
       return x.displayAllNewCustomer();
    }
    public Oldcustomer SearchForOldCustomer(long mcode)
    {
        Oldcustomer x=new Oldcustomer();
        return x.SearchCustomermcode(mcode);
    }
    public Newcustomer SearchForNewCustomer(int SSN)
            
    {
        Newcustomer x=new Newcustomer();
        return x.SearchCustomer(SSN);
    }    
    public boolean login(String Email,String Password)
    {
       
        if(Email.equals("Admin@yahoo.com")&&Password.equals("12345"))
            return true;
        
        return false;
        
    }
}
