/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Users;

/**
 *
 * @author amr
 */
public class Meter {
   private int MID;
   private String type;
   private int phase;

   public Meter()
   {
       
   }
    public Meter(int MID, String type, int phase) {
        this.MID = MID;
        this.type = type;
        this.phase = phase;
    }

    public void setMID(int MID) {
        this.MID = MID;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setPhase(int phase) {
        this.phase = phase;
    }

    public int getMID() {
        return MID;
    }

    public String getType() {
        return type;
    }

    public int getPhase() {
        return phase;
    }
    
   @Override
    public String toString()
    {
        return this.MID+" "+this.phase+" "+this.type;
    }
}
