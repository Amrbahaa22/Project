
package Users;

import ControlUnit.DTC;
import ControlUnit.FileManger;
import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;


public class Bill implements Serializable{
    public double cost;
    private String s;
    private DTC d;
    public boolean check;
     
    int RID;//This For Region ID;
    public static ArrayList<Bill> B;
    String FileName="E:\\Project\\Codes\\Project\\Data\\Bills";
    FileManger FManger;
   
    public Bill()
    {
        this.cost=0;
        d=new DTC();
        this.s=d.getdate();
        FManger=new FileManger();        
        B=new ArrayList<Bill>();
    }
    public Bill(double bill,boolean check)
    {   
        this.cost=bill;
        this.check=check;
        FManger=new FileManger();
        B=new ArrayList<Bill>();
    }
    public double getBill(){
        return this.cost;
    }
    public String getDate() {
        return s;
    }
    public boolean isCheck() {
        return check;
    }
    public boolean AddBill()
    {
        File file = new File(FileName);
        boolean empty = file.length() == 0;
        try
        {
            if(!empty)
            {
                this.loadFromFile();
                B.add(this);
                return commitToFile();
            }
            else
            {
                 B.add(this);
                 return commitToFile();
            }

        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return false;
    }
    public void loadFromFile()
    {
       B=(ArrayList<Bill>)this.FManger.read(FileName);
    }
    public boolean commitToFile()
    {
        return this.FManger.write(FileName, B);
    }
    public String ViewAllBills(int id)
    {
        File file = new File(FileName);
        boolean empty = file.length() == 0;
        try
        {
            String s="All Bills ";
            if(!empty)
            {
                for(Bill x:B)
                {
                   s+=x.toString();
                }
                return s;
            }
            else
            {
                return "No Data Were Entered Before \n";
            }
            
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return null;

    }
    @Override
    public String toString()
    {
        if(this.check==false)
        {
            return this.cost+" "+this.s+" "+"Not paid"+" ";
        }
        return this.cost+" "+this.s+" "+"paid Successfull"+" ";
        
    }
    
}
