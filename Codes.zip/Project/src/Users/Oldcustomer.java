package Users;

import ControlUnit.Email;
import ControlUnit.FileManger;
import Users.Customer;
import ControlUnit.Operator;
import java.io.File;
import java.io.Serializable;
import java.util.*;
import java.lang.*;

public class Oldcustomer extends Customer implements Serializable{
    Meter M;
    private long creading;
    private long preading;
    private String complain;
    public int ctr;
    public Bill bill;
    /*This is windows not In linus  public static*/ String FileName="E:\\Project\\Codes\\Project\\Data\\OldCustomer.txt";
    /*This is In linux  not In windows public static String FileName="/media/amr-bahaa/53F36C0F15034F37/Project/Data/OldCustomer.txt";*/
    Email E;
    Operator op;
    public static ArrayList<Oldcustomer> OldCustomer=new ArrayList<Oldcustomer> ();
    
    
    public Oldcustomer()
    {
       super();
       this.op=new Operator() ;
       this.preading=-1;
       this.bill=new Bill();
       this.M=new Meter();
    }
    public Oldcustomer(String Fname,String Lname,String email,String bday,int age,int SSN,Region R,int Mid,String Mtype,int Mphase)
    {
      super(Fname,Lname,email,bday,age,SSN,R);
      this.complain=",";
      this.preading=-1;
      this.op=new Operator();
      this.bill=new Bill();
      this.bill.RID=R.RID;
      this.M=new Meter(Mid, Mtype, Mphase);
    }      
    public void SetCreadibg(long creading)
    {
        this.creading=creading;
    }
    private void setPreading(long preading)
    {
        
        int index=this.getCustomermcodeIndex(this.M.getMID());
        if(index!=-1)
        OldCustomer.get(index).preading=preading;  //if Customer exist 
        else
            this.preading=preading;
    }
    public long getpreading()
    {
       return this.preading;
    }
    private long getCreadibg()
    {
        return this.creading;
    }
    private void setBill(long reading)
    {
        this.bill.cost=op.SetConsumption(reading);
        this.bill.AddBill();
       
    }
    public boolean enterReading(long creading)
    {
        if(op.validate(this.creading,this.preading))
        {
            long reading=creading-this.getpreading();
            this.setBill(reading);
            this.setPreading(this.creading);
            this.SetCreadibg(creading);
            return true;
        }
        else
        return false;
        

    }
    private long getcReading()
    {
      return this.creading;   
    }
    
    //Old Customer Methods
    public void setctr(int ctr)
    {
        this.ctr=ctr;
    }
    public int getctr()
    {
        return this.ctr;
    }
    private void taxinc()
    {
        this.ctr++;
    }
    
    public void SendWarning(String UserEmail,String UserPassword,String ClientEmail,String M)
    {
        E.send(UserEmail, UserPassword, ClientEmail, M);
    }
    public boolean check()
    {
        if(ctr==3)
        {
            return true;
        }
        return false;
    }
        
    public void complain(String complain)
    {
        this.complain=complain;
    }  

    
    public boolean pay(double pay)
    {   
        
        if(pay!=0)
        { 
           op.paybill(bill);
           if(this.ctr>0) ctr--;
           
           return true;
        }
        else
        {
            taxinc();
        }
        return false;
    }
    
    @Override
    public String toString()
    {
        return this.toString()+" "+this.R.toString()+" "+this.M.toString()+" "+this.getpreading()+" "+this.getcReading()+" "+this.bill.toString()+" ";
     
    }
    
    private int getCustomermcodeIndex(long mcode)
    {
        for(int i=0;i<OldCustomer.size();++i)
        {
            if(OldCustomer.get(i).M.getMID()==mcode)
            {
                return i; 
            }
                
        }
        return -1;
    }
    
    //Files Methods
    public boolean addOldCustomer()//This is for Admin Not for anything Else
    {
        File file = new File(FileName);
        boolean empty = file.length() == 0;
        try
        {
            if(!empty)
            {
                this.loadFromFile();
                OldCustomer.add(this);
                return commitToFile();
            }
            else
            {
                 OldCustomer.add(this);
                 return commitToFile();
            }

        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return false;

    }
    public void loadFromFile()
    {
        OldCustomer=(ArrayList<Oldcustomer>)this.FManger.read(FileName);
    }
    public boolean commitToFile()
    {
        return this.FManger.write(FileName, OldCustomer);
    }
    public ArrayList<Oldcustomer> displayAllOldCustomer()//Mafrod hena 2adelo id
    {
        File file = new File(FileName);
        boolean empty = file.length() == 0;
        try
        {
            if(!empty)
            {
                this.loadFromFile();
                return OldCustomer;
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        
        return null;

    }
    public ArrayList<Bill>AllbillsofRegion(int ID)
    {
        ArrayList<Bill> b=new ArrayList<Bill>();
        this.loadFromFile();
        for(Oldcustomer x:OldCustomer)
        {
            if(x.bill.RID==ID)
            {
                b.add(x.bill);
            }
        }
        return b;
    }
    public ArrayList<Oldcustomer> displayAllOldCustomerofRegion(int id)//Mafrod hena 2adelo id
    {
        ArrayList<Oldcustomer> oc=new ArrayList<>();
        File file = new File(FileName);
        boolean empty = file.length() == 0;
        try
        {
                if(!empty)
                {
                    this.loadFromFile();
                    for(Oldcustomer x:OldCustomer)
                    {
                        if(x.getRegion().getRID()==id)
                            oc.add(x);
                    }
                    return oc;
                }
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
        return null;


    }
    public double TotalCollected()
    {
        File file = new File(FileName);
        boolean empty = file.length() == 0;
        try{
            if(!empty)
            {
                loadFromFile();
                double Total=0;
                for(Oldcustomer x:OldCustomer)
                {
                    Total+=x.bill.cost;
                }
                return Total;
            }
        }
        catch(NullPointerException e)
        {
            System.out.println(e);
            
        }
        return 0;
    }
    public Oldcustomer SearchCustomermcode(long mcode)
    {
        File file = new File(FileName);
        boolean empty = file.length() == 0;
        try
        {
            if(!empty)
            {
                this.loadFromFile();
                int index=getCustomermcodeIndex(mcode);
                if(index!=-1)
                {
                    return OldCustomer.get(index);
                }
            //this.M.getMID()=OldCustomer.get(index).M.getMID();
                return null;
            }

        }
        catch (NullPointerException e)
        {
            System.out.println(e);
        }
        return null;
        
    }
    public boolean updateCustomer(long oldmcode,Oldcustomer x)
    {
        File file = new File(FileName);
        boolean empty = file.length() == 0;
        try
        {
            if(!empty)
            {
                loadFromFile();
                int index = getCustomermcodeIndex(this.M.getMID());

                if (index != -1) {
                OldCustomer.set(index, this);
                return commitToFile();
        }

        return false;
            }
      
        }
        catch(NullPointerException e)
        {
            System.out.println(e);
        }
        return false;   
    }
    public boolean deleteCustomer(long oldmcode)
    {
        File file = new File(FileName);
        boolean empty = file.length() == 0;
        try
        {
            if(!empty)
            {
                this.loadFromFile();
                int index=getCustomermcodeIndex(this.M.getMID());
                if(index!=-1)
                {
                    OldCustomer.remove(index);
                    commitToFile();
                    System.out.println("Customer Removed Successfully");
                    return commitToFile();
                }

            }
            

        }
        catch(NullPointerException e)
        {
            System.out.println(e);
        }
        
        return false;
    }
    
     
}
