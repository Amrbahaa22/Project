/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Users;

import ControlUnit.FileManger;
import java.io.Serializable;

/**
 *
 * @author amr
 */
public class Region implements Serializable{
    public int RID;
    private String RName;
    private String RGove;
    
   // FileManger myFile=new FileManger();
    
    public Region()
    {
        
    }
    public Region(int RID,String RName,String RGov)
    {
        this.RID=RID;
        this.RName=RName;
        this.RGove=RGov;
    }
    
    protected void SetRID(int RID)
    {
        this.RID=RID;    
    }
    public int getRID()
    {
        return this.RID;
    }
    
    protected void SetRName(String RName)
    {
        this.RName=RName;
    }
    public String getRName()
    {
        return this.RName;
    }
    
    protected void SetRGove(String RGOV)
    {
        this.RGove=RGOV;
    }
    public String getRGove()
    {
        return this.RGove;
    }
    
    @Override
    public String toString()
    {
        return this.RName+" "+this.RGove+" Government";
    }
}
