/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Users;
import ControlUnit.DTC;
import ControlUnit.FileManger;
import java.io.Serializable;
import java.util.*;
import java.lang.*;

public  abstract class Customer extends Person implements Serializable{

    protected Region R;
    protected DTC d;
    protected String dte;
    FileManger FManger;
    public Customer()
    {
        this.d=new DTC();
        this.R=new Region();
        this.dte=d.getdate();
        FManger=new FileManger();
    }
    public Customer(String FName,String LName,String Email,String bday,int age,int SSN,Region R)
    {
      super(FName,LName,Email,bday,age,SSN);
      this.R=R;
      this.d=new DTC();
      this.dte=d.getdate();
      FManger=new FileManger();
    }
    public void setDte(DTC dte) {
        
        this.dte = dte.getdate();
    }
    public void setR(Region R) {
        this.R = R;
    }
    void setRegion(Region R)
    {
        this.R=R;
    }
    public Region getRegion()
    {
        return this.R;
    } 
    
    public String toStringC()
    {
        return this.toStringP()+" "+this.R.toString();
    }
    

}
