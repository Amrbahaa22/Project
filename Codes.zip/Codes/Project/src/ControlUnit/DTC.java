/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ControlUnit;

import java.util.Date;
import java.io.*;
import java.text.DateFormat;
import java.util.Locale;

public class DTC implements Serializable{
    private Date d;
    private DateFormat df;
    private String s;

    public DTC() {
        this.d=new Date();
        this.df=DateFormat.getDateInstance(DateFormat.FULL);
        this.s = df.format(d);
    }
    
    public String getdate()
    {
        return this.s;
    }
}
