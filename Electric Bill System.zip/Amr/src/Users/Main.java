package Users;




import ControlUnit.Admin;
import ControlUnit.FileManger;
import ControlUnit.Operator;
import Users.Customer;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.Icon;
import javax.swing.JOptionPane;
import javax.swing.plaf.IconUIResource;


public class Main {

    public static Region R1=new Region(1,"Hadayek El Maady","Cairo");
    public static Region R2=new Region(2,"Maady","Cairo");
    public static Region R3=new Region(3,"Sakanat El Maady","Cairo");
    public static void main(String[] args) throws FileNotFoundException, IOException {
        
       //Newcustomer x=new Newcustomer("Amr","Bahaa", "Amr@yahoo.com","2020", 20, 1000, R1);
      //x.addNewCustomer();
         
        /*Operator op=new Operator();
        Admin  AD=new Admin();
        MyExceptions ex=new MyExceptions();

        Scanner in=new Scanner(System.in);
        String AOEmail,AOPassword;
        String FName;
        String LName;
        String Email;
        String Password;
        String bday;
        int Age;
        int SSN;
        
        JOptionPane.showMessageDialog(null,"\t\t\t Welcome This is Electric Bill System \t\t\t\n Please Enter your Email and Password\n");
        AOEmail=ex.checkEmail("Email");
        AOPassword=JOptionPane.showInputDialog("Enter your Password please ");
        if(AD.login(AOEmail,AOPassword))
        {
            JOptionPane.showMessageDialog(null,"Welcome Admin \n Please Select The operation you want to do \n");
            JOptionPane.showMessageDialog(null,"\t\t\t\t Menu List \t\t\t\t");
            JOptionPane.showMessageDialog(null,"1-View All bills of Specific Region \n 2-View Total Collected \n 3-Add New Customer \n 4-Delete Old Customer \n 5-Delete New Customer \n 6-Update New Customer to Old Customer\n 7- Update Old Customer \n 8-List All New Customer \n 9-list All Old Customer \n 10-Exit");
            int n=Integer.parseInt(JOptionPane.showInputDialog("Enter your Choic please "));
            while(n!=10)
            {
                
                switch(n)
                {
                    case 1:
                        int ID=Integer.parseInt(JOptionPane.showInputDialog("Please Enter Region to View it's bill\n1- Hadayek El Maady \t\t 2- Maady \t\t 3- Saakanat El Maady \t\t"));
                        AD.veiwAllBills(ID);
                        break;
                        
                    case 2:
                        AD.TotalCollected();
                        break;
                    case 3:
                       FName=ex.Namechar("FirstName");
                       LName=ex.Namechar("Last Name");
                       Email=ex.checkEmail("Email");
                       Password=ex.checkPassLength("Password");
                       bday=JOptionPane.showInputDialog("Enter Birthday");
                       Age=ex.checkPositive("Age");
                       SSN=ex.checkPositive("Social Security Number");
                       int Check;
                       JOptionPane.showMessageDialog(null,"Please Select A region For This Customer\n 1- Hadayek El Maady \t\t 2- Maady \t\t 3- Saakanat El Maady \t\t");
                       Check=ex.checkPositive("Check");
                       while(Check<1&&Check>3)
                       {
                            System.out.println("Wrong Number \n Please Select A region For This Customer\n 1- Hadayek El Maady \t\t 2- Maady \t\t 3- Saakanat El Maady \t\t");
                            Check=in.nextInt();                            
                       }
                        if(Check==1)
                        {
                            AD.addNewCustomer(FName, LName, Email, Password, bday, Age, SSN, R1);
                        }
                        else if(Check==2)
                        {
                             AD.addNewCustomer(FName, LName, Email, Password, bday, Age, SSN, R2);
                        }
                        else
                        {
                             AD.addNewCustomer(FName, LName, Email, Password, bday, Age, SSN, R3);
                        }
                        break;
                        
                    case 4:
                        AD.displayAllOldCustomer();
                        System.out.println("Please Enter Customer Meter Code to be Deleted");
                        long mcode;
                        mcode=ex.checkPositive("Meter Code");
                        AD.deleteOldCustomer(mcode);
                       break;
                       
                    case 5:
                        AD.displayAllNewCustomer();
                       JOptionPane.showMessageDialog(null,"Please Enter New Customer Email To be Deleted");
                        Email=ex.checkEmail("Email");
                        //AD.deleteNewCustomer(Email);
                        break;
                        
                    case 6:
                        AD.displayAllNewCustomer();
                        JOptionPane.showMessageDialog(null,"Please Enter SSN Of Customer To be Updated");
                        //Email=ex.checkPositive("SSN");
                        int MID=ex.checkPositive("Meter Code");
                        String Mtype=ex.Namechar("Meter Type");
                        int Phase=ex.checkPositive("Phase of Meter Code");
                        //if(AD.updateNewCustomertoOld(MID, Mtype, Phase, SSN))
                        JOptionPane.showMessageDialog(null,"Updated Successfully","Succussful Process",JOptionPane.OK_OPTION);
                        //else
                         JOptionPane.showMessageDialog(null,"Failed to be Updated","Error",JOptionPane.ERROR_MESSAGE);
                        break;
                        
                    case 7:
                        AD.displayAllOldCustomer();
                        JOptionPane.showMessageDialog(null,"Please Enter Meter Code of customer to be updated");
                        MID=ex.checkPositive("Mete Id");
                        
                        if(AD.SearchForOldCustomer(MID)!=null)
                        {
                            int c;
                            do
                            {
                               c=Integer.parseInt(JOptionPane.showInputDialog("Please Enter Field TO be Updated\t\t 1-Email and Password \n 2-Region"));
                             }while(c<1||c>2);
                            if(c==1)
                            {
                                 Email=ex.checkEmail("Email");
                                 Password=JOptionPane.showInputDialog("Enter Password");
                            }
                            else if(c==2)
                            {
                                
                                JOptionPane.showMessageDialog(null,"Please Select A region For This Customer\n 1- Hadayek El Maady \t\t 2- Maady \t\t 3- Saakanat El Maady \t\t");
                                Check=ex.checkPositive("Check");
                                while(Check<1&&Check>3)
                                {
                                     System.out.println("Wrong Number \n Please Select A region For This Customer\n 1- Hadayek El Maady \t\t 2- Maady \t\t 3- Saakanat El Maady \t\t");
                                     Check=in.nextInt();                            
                                }
                                 if(Check==1)
                                 {
                                     //AD.addNewCustomer(FName, LName, Email, Password, bday, Age, SSN, R1);
                                 }
                                 else if(Check==2)
                                 {
                                      //AD.addNewCustomer(FName, LName, Email, Password, bday, Age, SSN, R2);
                                 }
                                 else
                                 {
                                      //AD.addNewCustomer(FName, LName, Email, Password, bday, Age, SSN, R3);
                                 }
                            }
                }
                           
                 
                        else
                        
                          JOptionPane.showMessageDialog(null,"Can't Be Found");
                        
                        
                    break;    
                }
                JOptionPane.showMessageDialog(null,"Welcome Admin \n Please Select The operation you want to do \n");
                JOptionPane.showMessageDialog(null,"\t\t\t\t Menu List \t\t\t\t");
                JOptionPane.showMessageDialog(null,"1-View All bills of Specific Region \n 2-View Total Collected \n 3-Add New Customer \n 4-Delete Old Customer \n 5-Delete New Customer \n 6-Update New Customer\n 7- Update OldCustomer \n 8-List All New Customer \n 9-listAllOldCustomer \n 10-Exit");
                n=Integer.parseInt(JOptionPane.showInputDialog("Enter your Choic please "));
            }
        }
        else if(op.login(AOEmail,AOPassword))
        {
            System.out.println("Welcome Operator \n Please Select The operation you want to do \n");
        }
        else
        {
            System.out.println("Sorry Wrong Email Or Password ");
        }*/
        
    }
    
}
