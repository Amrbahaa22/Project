
package Users;

import ControlUnit.DTC;
import ControlUnit.FileManger;
import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;


public class Bill implements Serializable{
    
    public double cost;
    private String s;
    private DTC d;
    public boolean check;
    public long Mcode;
    int RID;//This For Region ID;
    
    public static ArrayList<Bill> B;
    public static String FileName="/home/amr-bahaa/GitHub FolderShare/RUN/New folder (2)/Amr/Data/Bills.txt";
    //public static String FileName="/home/amr-bahaa/GitHub FolderShare/Codes/Project/Data/Bills.txt";
    FileManger FManger;
   
    public Bill()
    {
        this.cost=0;
        d=new DTC();
        this.s=d.getdate();
        FManger=new FileManger();        
        B=new ArrayList<Bill>();
    }
    public Bill(double bill,boolean check,long mcode,int RID)
    {   
        this.cost=bill;
        this.check=check;
        this.Mcode=mcode;
        this.RID=RID;
        FManger=new FileManger();
        B=new ArrayList<Bill>();
    }
    public long getMcode()
    {
        return this.Mcode;
    }
    public void SetCost(double cost){
        this.cost=cost;
    }
    public void SetRID(int id){
        this.RID=id;
    }
    public double getBill(){
        return this.cost;
    }
    public String getDate() {
        return s;
    }   
    public boolean isCheck() {
        return check;
    } 
    public boolean AddBill(){
        File file = new File(FileName);
        boolean empty = file.length() == 0;
        try
        {
            if(!empty)
            {
                this.loadFromFile();
                B.add(this);
                return commitToFile();
            }
            else
            {
                 B.add(this);
                 return commitToFile();
            }

        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return false;
    }
    public void loadFromFile(){
       B=(ArrayList<Bill>)this.FManger.read(FileName);
    }
    public boolean commitToFile(){
        return this.FManger.write(FileName, B);
    }
    public ArrayList<Bill> ViewAllBills(int id){
        File file = new File(FileName);
        boolean empty = file.length() == 0;
        ArrayList<Bill> nwb=new ArrayList<Bill>();
        try
        {  
            if(!empty)
            {
                this.loadFromFile();
                for(Bill x:B)
                {
                    if(x.RID==id)
                    {
                        nwb.add(x);
                    }
                    
                    
                }
                return nwb;
            }            
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return null;

    }
    public Bill getBill(long Mcode)
    {
        File file = new File(FileName);
        boolean empty = file.length() == 0;
        try
        {  
            if(!empty)
            {
                this.loadFromFile();
                for(Bill x:B)
                {
                    if(x.Mcode==Mcode)
                    {
                       return x;
                    }
                    
                    
                }
               
            }            
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return null;

    }
    public double totalcollected()
    {
        File file = new File(FileName);
        boolean empty = file.length() == 0;
        double Total=0;
        try
        {  
            if(!empty)
            {
                this.loadFromFile();
                for(Bill x:B)
                {
                    
                  Total+=x.cost;   
                }
               return Total;
            }            
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return 0;

    }
}
