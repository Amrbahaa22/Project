/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Users;

import java.io.Serializable;

/**
 *
 * @author amr
 */
public class Meter implements Serializable{
   private long MID;
   private int phase;

   public Meter()
   {
       
   }
    public Meter(long MID, int phase) {
        this.MID = MID;
        this.phase = phase;
    }

    public void setMID(long MID) {
        this.MID = MID;
    }

    public void setPhase(int phase) {
        this.phase = phase;
    }

    public long getMID() {
        return MID;
    }

    public int getPhase() {
        return phase;
    }
    

}
