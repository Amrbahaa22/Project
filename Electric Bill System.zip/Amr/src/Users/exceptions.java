/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Users;

/**
 *
 * @author Onsymers
 */
public class exceptions {
    public boolean CheckName(String x){
        if(x.matches("[a-zA-Z]+")){
            return true;
        }
        else
            return false;
    }
    
    public boolean checkSSN(String x){
        if(x.matches(".*\\d+.*") && x.length()==14 && Long.parseLong(x)>0)
            return true;
        else 
            return false;
    }
    
    public boolean Checkmail(String x){
        if (x.contains("@") && x.contains(".")) {
                return true;
            }
        else
            return false;
    }
    
    public boolean CheckAge(String x){
        if(Integer.parseInt(x)>=21 && Integer.parseInt(x)<=100){
            return true;
        }
        else{
            return false;
        }
    }
    
    public boolean CheckPostive(String x){
        if(Integer.parseInt(x)>0){
            return true;
        }
        else
            return false;
    }
}
