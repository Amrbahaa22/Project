
package Users;

import ControlUnit.FileManger;
import java.io.Serializable;

public abstract class Person implements Serializable{
    
    private String FName;
    private String LName;
    private String Email;
    private String bday;
    private int Age;
    private long SSN; 
    public FileManger FManger;
    
    public Person()
    {
         FManger = new FileManger();
            
    }
    public Person(String FName,String LName,String Email,String bday,int age,long SSN)
    {
        this.FName=FName;
        this.LName=LName;
        this.Email=Email;
        this.bday=bday;
        this.Age=age;
        this.SSN=SSN;
        FManger = new FileManger();
    }
    public void  setFname(String FName)
    {
        this.FName=FName;
    }
    public  String  getFname()
    {
        return this.FName;
    }
    
    public void setLname(String LName)
    {
        this.LName=LName;
    }
    public String getLname()
    {
        return this.LName;
    }
            
    public void setbday(String bday)
    {
        this.bday=bday;
    }
    public String getbday()
    {
        return this.bday;
    }
    
    public void setEmail(String Email)
    {
        this.Email=Email;
    }
    public String getEmail()
    {
        return this.Email;
    }
    public void setage(int age)
    {
        this.Age=age;
    }
    public int getage()
    {
        return this.Age;
    }
    
    public void setSSN(long SSN)
    {
        this.SSN=SSN;
    }
    public long getSSN()
    {
        return this.SSN;
    }

    
}
