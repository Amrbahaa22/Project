package Users;

import ControlUnit.Email;
import ControlUnit.FileManger;
import Users.Customer;
import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;


public class Newcustomer extends Customer implements Serializable{
    
    Email E;
    public static String  FileName="/home/amr-bahaa/GitHub FolderShare/RUN/New folder (2)/Amr/Data/NewCustomer.txt";
    //public static String FileName="E:\\New folder (2)\\Amr\\Data\\NewCustomer.txt";
    public static ArrayList<Newcustomer>NewCustomer=new ArrayList<Newcustomer>();
    public Newcustomer()
    {
        super();
        
    }
    public Newcustomer(String Fname,String Lname,String Email,String bday,int age,long SSN,Region R)
    {
        super(Fname,Lname,Email,bday, age, SSN, R);
     
    }    
    void attatch()
    {
        
    }
    public void MeterReady(String UserEmail,String UserPassword,String ClientEmail,String M)
    {
        E.send(UserEmail, UserPassword, ClientEmail, M);
    }
    
    //FileManger Methods
    public void loadFromFile()
    {
        NewCustomer=(ArrayList<Newcustomer>)this.FManger.read(FileName);
    }
    public boolean addNewCustomer()
    {
        File file = new File(FileName);
        boolean empty = file.length() == 0;
        try
        {
            
            if(!empty)
            {
                this.loadFromFile();
                NewCustomer.add(this);
                return commitToFile();
            }
            else
            {
                 NewCustomer.add(this);
                 return commitToFile();
            }

        }
        catch (NullPointerException e)
        {
            System.out.println(e);
            
        }
        return false;
    }
    public boolean commitToFile()
    {
        return this.FManger.write(FileName,NewCustomer);
    }
    public ArrayList<Newcustomer> displayAllNewCustomer()
    {
        File file = new File(FileName);
        boolean empty = file.length() == 0;
        try
        {
            if(!empty)
            {
                this.loadFromFile();
                return NewCustomer;
            }

        }
        catch (NullPointerException e)
        {
            System.out.println(e);
        }
        return null;
    }
     public Newcustomer SearchCustomer(long SSN)
     {
        File file = new File(FileName);
        boolean empty = file.length() == 0;
         try
         {
            if(!empty)
            {
                this.loadFromFile();
                int index=getNewCustomerIndex(SSN);
                if(index!=-1) return NewCustomer.get(index);
            } 
         }
         catch(NullPointerException e)
         {
             System.out.println(e);
         }
          return null;
     }
    private int getNewCustomerIndex(long SSN) {
        for (int i = 0; i < NewCustomer.size(); i++) {
            if (NewCustomer.get(i).getSSN()== SSN) {
                return i;
            }
        }

        return -1;
    }
    public boolean updateCustomer()
    {
        File file = new File(FileName);
        boolean empty = file.length() == 0;
        try
        {
            if(!empty)
            {
                    loadFromFile();
                    int index = getNewCustomerIndex(this.getSSN());
                    if (index != -1) {
                        NewCustomer.set(index, this);
                        return commitToFile();
                    }
            }

        }
        catch(NullPointerException e)
        {
            System.out.println(e);
        }
        return false;
    } 
    public boolean deleteCustomer(long SSN)
    {
        File file = new File(FileName);
        boolean empty = file.length() == 0;
        try
        {
            if(!empty)
            {
                loadFromFile();
                int index=getNewCustomerIndex(SSN);
                if(index!=-1)
                {
                    NewCustomer.remove(index);
                    return commitToFile();
                }          
            }
   
             
        }
        catch(NullPointerException e)
        {
            System.out.println(e);
        }
        return false;
    }
    public boolean SearchCustomerIndex(long SSN)
     {
        File file = new File(FileName);
        boolean empty = file.length() == 0;
         try
         {
            if(!empty)
            {
                this.loadFromFile();
                int index=getNewCustomerIndex(SSN);
                if(index!=-1) return true;
            } 
         }
         catch(NullPointerException e)
         {
             System.out.println(e);
         }
          return false;
     }
}
