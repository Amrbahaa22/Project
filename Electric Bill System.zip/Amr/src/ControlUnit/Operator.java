/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ControlUnit;

import ControlUnit.FileManger;
import Users.Bill;
import Users.Newcustomer;
import Users.Oldcustomer;
import Users.Person;
import Users.Region;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

public class Operator extends Person implements Serializable{
    
     private double tarrif;
     public Operator()
     {
       
     }
     public Operator(String FName,String LName,String Email,String password,String bday,int age,int SSN)
     {
         super(FName, LName, Email, bday, age, SSN);
     }
     //New Customer Methods

     
     //Old Customer Methods
    private double define(long Reading)
    {
        
        if(Reading>=0&&Reading<=100)
        {
            this.tarrif=0.1;
            
        }
        else if(Reading>100&&Reading<=200)
        {
            this.tarrif=0.2;
        }
        else if(Reading>200&&Reading<=300)
        {
            this.tarrif=0.3;
        }
        else if(Reading>300&&Reading<=400)
        {
            this.tarrif=0.4;
        }
        else if(Reading>400&&Reading<=500)
        {
            this.tarrif=0.5;
        }
        else if(Reading>500&&Reading<=600)
        {
            this.tarrif=0.6;
        }
        else if(Reading>600&&Reading<=700)
        {
            this.tarrif=0.7;
        }
        else if(Reading>700&&Reading<=800)
        {
            this.tarrif=0.8;  
        }
        else if(Reading>900&&Reading<=1000)
        {
            this.tarrif=1;
        }
        return Reading*tarrif;
    }
    public double SetConsumption(long reading)
    {
        
        double b=define(reading);
        return b;
    }    
    /*protected void Collectedpayments()
    {
        Oldcustomer x=new  Oldcustomer();
        System.out.println(x.TotalCollected());
    }*/    
    private Bill printbillFile(long mcode)
    {
        Bill b=new Bill();
        return b.getBill(mcode);
            
    }
    public void paybill(Bill bill)
    { 
        bill.check=true;
        
    }
    public boolean validate(long creading,long preading)//Ask About it
    {
        return creading>preading;
    }
    public ArrayList<Bill> viewregionbill(int id)
    {
         Oldcustomer x=new Oldcustomer();
         return x.AllbillsofRegion(id);
    }
    public void stop(long mcode)
    {
        Oldcustomer x=new Oldcustomer();
        x.SearchCustomermcode(mcode);
        if(x.check())
        {
            System.out.println("Customer Reached The MaxiMum limit of Unpaid bill \nCutstomer Has been deleted Successfully");
            x.deleteCustomer(mcode);
        }
        else
        {
            System.out.println("Customer did'nt reach the Maximum limit of unpaid bill");
        }
    }
    public boolean login(String Email, String Password)
    {
        if(Email.equals("Operator@yahoo.com")&&Password.equals("56789"))
        return true;
        
        return false;
    }
}
