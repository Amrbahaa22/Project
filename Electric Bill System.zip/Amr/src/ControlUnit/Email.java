 
 
package ControlUnit;

import java.util.*;  
import javax.mail.*;  
import javax.mail.internet.*;  
import javax.activation.*; 
import java.io.*;
import java.lang.*;

public abstract class Email{  

    public boolean send(String UserEmail,String UserPassword,String ClientEmail,String M)
    {
        String host="mail.javatpoint.com";  
        final String user=UserEmail;//change accordingly  
        final String password=UserPassword;//change accordingly  
    
        String to=ClientEmail;//change accordingly  
  
        //Get the session object  
        Properties props = new Properties();  
        props.put("mail.smtp.host",host);  
        props.put("mail.smtp.auth", "true");  

        Session session = Session.getDefaultInstance(props,  
        new javax.mail.Authenticator() 
        {  
            @Override
            protected PasswordAuthentication getPasswordAuthentication()
            {  
               return new PasswordAuthentication(user,password);  
            }
        });
  
         //Compose the message  
        try {  
        MimeMessage message = new MimeMessage(session);  
        message.setFrom(new InternetAddress(user));  
        message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));  
        message.setSubject("This Message is From Electricity System");  
        message.setText(M);  
       
        //send the message  
        Transport.send(message);  
  
        System.out.println("message sent successfully...");  
         return true;
        }catch (MessagingException e) {
            e.printStackTrace();
            System.out.println("Faild To Send Message..");  
            return true;
        }  
  
   }

}  